# ShopEase - E-Commerce Web Application

An interactive and responsive E-Commerce application.

## Features
- Product listing
- Add to Cart
- Remove items
- Cart count
- Total price calculation
- Checkout simulation
- Responsive design

## Technologies Used
- HTML
- CSS
- JavaScript

## Developed By
Kasa Sri Lakshmi Swetha